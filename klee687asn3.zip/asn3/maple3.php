<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset= "utf-8">
	<title> KJ's Assignment3 </title>
</head>
<body>

<h2> Show the name of the official who has officiated the most Leaf wins </h2>

<?php
	include 'db.php';  //This php file will make a connection to the database you created.

	//this query will return the officiator's first and last name and the number of official ID whose team was Maple Leafs. 
	$query = "SELECT refsOfficial.FirstName, refsOfficial.LastName, COUNT(refsOfficial.OfficialID)
			  FROM refsOfficial, Plays as a, Plays as b, Team as c, Team as d, OfficialRegular 
			  WHERE c.TeamName='Maple Leafs' AND OfficialRegular.GameID=a.GameID
			  AND refsOfficial.OfficialID=OfficialRegular.OfficialID
			  AND a.TeamID=c.TeamID AND b.TeamID=d.TeamID
			  AND d.TeamName!=c.TeamName AND a.GameID=b.GameID   
			  AND a.score>b.score GROUP BY refsOfficial.OfficialID ORDER BY COUNT(*) DESC";
			  // by counting the number of official id and descending those, we can see whose counts are the greatest.  

				// firstname | lastname | count
				//-----------+----------+-------
				// Regis     | Philbin  |     2  <----
				// Rosie     | Odonnell |     2  <----
				// Rosie     | Fox      |     2  <----
				// Courtney  | Fox      |     1  <----



	$result = pg_query($query);
	if (!$result) {
		die ("Database query failed!");
	}
	
	$row=pg_fetch_array($result);
	echo $row[0], " ",$row[1]," officiated the ","<b>",$row[2],"</b>"," Maple Leafs game(s).";
    echo "<br>";
	while ($row1=pg_fetch_array($result)) {
		if ($row1[2] == $row[2]) {
			echo $row1[0], " ",$row1[1]," officiated the ","<b>",$row1[2],"</b>"," Maple Leafs game(s).";
			echo "<br>";
		}
	}
	
	pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
	pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>

</body>
</html>
