<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset= "utf-8">
<title> KJ's Assignment3 </title>
</head>
<body>
<h2> Show the scores for all the games that the Leafs played in and their opponents name and city </h2>

<?php
	include 'db.php'; //This php file will make a connection to the database you created.

	// the query will show the scores for all the games that the Leafs played in and their opponents name and city 
	$query = "SELECT x.Score, b.TeamName, b.TeamCity, y.Score  
		  FROM Plays as x, Plays as y, Team as a, Team as b 
		  WHERE x.TeamID = a.TeamID AND y.TeamID = b.TeamID 
		  AND a.TeamName = 'Maple Leafs' 
		  AND x.GameID = y.GameID AND a.TeamID != b.TeamID";

//		   score | teamname  | teamcity | score
//        -------+-----------+----------+-------
//     		   6 | Oilers    | Edmonton |     2 <----------
//     		   2 | Oilers    | Edmonton |     5 
//     		   3 | Red Wings | Detroit  |     2
//     		   3 | Red Wings | Detroit  |     1





$result = pg_query($query);
$row = pg_fetch_array($result);
echo "<b>The opponent's Team Name:</b> ".$row[1]."<br>";  
echo "<b>The opponent's Team City:</b> ".$row[2]."<br>"; 
echo "<b>Score [A]:</b> ".$row[0]."<br>";
echo "<b>Score [B]:</b> ".$row[3]."<br>";

pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</body>
</html>



