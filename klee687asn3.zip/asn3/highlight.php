<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset= "utf-8">
<title> Kyungjoo Lee CS3319 asn3 </title>
</head>
<body>
<h2> Let the user to pick a game id and output the teams </h2>
<?php
	include 'db.php';  //This php file will make a connection to the database you created.

	$gameID= $_POST["gameid"];

	//It will output the teams' city and teams' name that played in the game with the same gameid, each teams score, the city the game took place and the date of the game.
    $query = "SELECT game.GameID, game.Date, game.HeadOfficialID, game.GameCity, 
    		  a.TeamName, b.TeamName, a.TeamCity, b.TeamCity, x.Score, y.Score 
              FROM game, team as a, team as b, plays as x, plays as y 
              WHERE game.gameID='".$gameID."' AND x.gameID='".$gameID."' AND y.gameID='".$gameID."' 
              AND x.teamID>y.teamID AND x.teamID=a.teamID AND y.teamID=b.teamID";

    $result = pg_query($query);
    $row = pg_fetch_array($result);
	
	echo "<b>---------List.(1)---------</b><br><br>"; // List of game id, date and city 
	echo "<b>Game ID:  </b>", $row[0];
	echo "<br>";
	echo "<b>Game Date: </b>", $row[1];
	echo "<br>";
	echo "<b>Game City: </b>", $row[3];
	echo "<br><br>";
	echo "<b>Team A: </b>", $row[4];          //first team 
	echo "<br>";
	echo "<b>Team A's City: </b>", $row[6];   //the 1st team's city 
	echo "<br>";

    	if ($row[8] > $row[9]) {
		echo "<mark><b>Team A's Score: </b>", $row[8], "</mark>"; //the first team's score with highlight if it is greater than the second team's score
	} else {
		echo "<b>Team A's Score: </b>", $row[8];                 //if the 1st team's score is less than the second team, then no highlight 
	}
	
	echo "<br><br>";
	echo "<b>Team B: </b>", $row[5];                             //2nd team 
	echo "<br>";
	echo "<b>Team B's City: </b>", $row[7];
	echo "<br>";
	
	if ($row[9] > $row[8]) {
		echo "<mark><b>Team B's Score: </b>", $row[9], "</mark>";           //the second team's score with highlight if it is greater than the second team's score
	} else {
		echo "<b>Team B's Score: </b>", $row[9]; 							//if the second team's score is less than the second team, then no highlight
	}
	
	echo "<br><br>";
	
	// this query will give the first and last name of officiators and their official number who officiated the selected game.  
	$query1 = "SELECT DISTINCT FirstName, LastName, refsOfficial.OfficialID 	
			   FROM refsOfficial, OfficialRegular WHERE gameID='".$gameID."'";

	$result1 = pg_query($query1);
	
	echo "<b>---------List.(2)---------</b><br><br>";   // first and last name of officiators. 
	while ($row1 = pg_fetch_array($result1)) {
		echo("<li>");
		if ($row1[2] == $row[2]) {
			echo "<mark>", $row1[0], " ", $row1[1],"  < == **** ","</mark>";
		} else {
			echo $row1[0], " ", $row1[1];
		}
	}

pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</body>
</html>