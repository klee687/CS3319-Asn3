<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<?php
  $query='SELECT * FROM team ORDER BY TeamCity';
  $result = pg_query($query);
  if (!$result) {
     die ("Database query failed!");
  }
  pg_free_result($result);
?>