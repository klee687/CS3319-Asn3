<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> KJ's assignment3 </title>
</head>
<body>
<?php
session_start();
?>

<h1>Update a city name of your game</h1>                                                           
<?php
include 'db.php'; //This php file will make a connection to the database you created.
$gameID=$_SESSION["gameid"]; // the gameid was saved by SESSION. it was from updategame.php
$gameCity = $_POST["gamecity"]; //
$query = 'UPDATE game SET gamecity = \''.$gameCity.'\' WHERE gameid = \''.$gameID.'\'';
$result = pg_query($query);

  if ($gameCity == ""){ //if gamecity input was not given,
    die("If you did not intend to set your location empty, you should try again.".pg_last_error($connection));
}else{
      $row = pg_fetch_array($result);
      echo "The Game ID $gameID is now located in $gameCity.";
      }
  pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
  pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</body>
</html>