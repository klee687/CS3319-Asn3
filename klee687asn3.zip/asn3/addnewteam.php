<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> KJ's assignment3 </title>
</head>
<body>
<h2> Add a new team </h2>
<ol>

<?php
   include 'db.php'; //This php file will make a connection to the database you created.
   $TeamID= $_POST["teamid"]; //retrieve a Team ID that user inserted from a main page.
   $TeamName = $_POST["teamname"]; //retrieve a Team name that user inserted from a main page.
   $TeamCity =$_POST["teamcity"]; //retrieve a Team city that user inserted from a main page.
   $query1= 'SELECT TeamID AS TeamID FROM Team';
   $result = pg_query($query1);
   
   if ($TeamID =="" OR $TeamName == "" OR $TeamCity == ""){ // if one of those three variables are not given
          die("database query failed".pg_last_error($connection));
   }

   if (!$result) { // if the query was not executed 
          die("database query failed".pg_last_error($connection));
   }
     $row=pg_fetch_array($result); //returns an array that corresponds to $result.
     $query = "INSERT INTO team VALUES('" . $TeamID . "','" . $TeamCity . "','" . $TeamName . "');"; 
     if (!pg_query($query)){ // if the query failed,
        die("database query failed".pg_last_error($connection));
      }
     echo "Your team was added!"; //success 
   
   pg_close($connection); //close the connection 
?>
</ol>
</body>
</html>
