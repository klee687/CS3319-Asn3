<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset= "utf-8">
<title> KJ's Assignment3 </title>
</head>
<body>

<h2> Show the name of the official who has officiated the most Leafs games </h2>

<?php
	include 'db.php';  //This php file will make a connection to the database you created.

	//this query will return the officiator's first and last name and the number of official ID whose team was Maple Leafs. 
	$query = "SELECT refsOfficial.FirstName, refsOfficial.LastName, COUNT(refsOfficial.OfficialID) 
			  FROM refsOfficial, Plays, Team, OfficialRegular WHERE Team.TeamName='Maple Leafs' 
			  AND OfficialRegular.GameID=Plays.GameID 
			  AND OfficialRegular.OfficialID=refsOfficial.OfficialID 
			  AND Team.TeamID=Plays.TeamID GROUP BY refsOfficial.OfficialID ORDER BY COUNT(*) DESC"; 
			  // by counting the number of official id and descending those, we can see whose counts are the greatest.  

			// firstname | lastname | count
			//-----------+----------+-------
			// Rosie     | Odonnell |     3 <----------
			// Rosie     | Fox      |     3 <----------
			// Regis     | Philbin  |     2
			// Courtney  | Fox      |     1


	$result = pg_query($query);
	if (!$result) {
		die ("Database query failed!");
	}
	
	$row=pg_fetch_array($result);
	echo $row[0], " ",$row[1], " has officiated the ","<b>",$row[2],"</b>"," Maple Leafs game(s)."; // the officiator who officiated the most leafs games.
	echo "<br>ALSO<br>";

	$row1=pg_fetch_array($result); 									// another officiator who officiated the most leafs games.
		if ($row1[2] == $row[2]) {
			echo $row1[0], " ",$row1[1]," has officiated the ","<b>",$row1[2],"</b>"," Maple Leafs game(s)."; 
		}
	
	
pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</body>
</html>