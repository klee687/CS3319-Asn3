<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!--This php file will make a connection to the database you created-->
<?php
$dbhost = "dbserver";
$dbuser= "klee687";
$dbpass = "JTSDXPmNnz";
$dbname = "klee687assign2db";
$connection = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");
echo "<p>attempting to connect</p>";
if (!$connection) {
     echo "Database Connection Failed" ;
   }
?>
