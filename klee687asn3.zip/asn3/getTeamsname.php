<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> Kyungjoo Lee CS3319 asn3 </title>
</head>
<body>

<h2> List all Teams (every field) in alphabetical order by team name </h2>
    
<?php
   include 'db.php';  //This php file will make a connection to the database you created.
   $query = 'SELECT * FROM team ORDER BY TeamName';
   $result = pg_query($query); 
   if (!$result) { // if the query failed to be executed 
         die("database query2 failed.");
   }

   while ($row = pg_fetch_row($result)) {
     echo("<li>");
     echo "<b>Team ID: </b>".$row[0]."<li>";  //first row = team id 
     echo "<b>Team City: </b>".$row[1]."<li>"; //second row = team city 
     echo "<b>Team Name: </b>".$row[2]."<li>"; //third row = team name 
     }
     pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
?>

<?php
   pg_close($connection); // close the connection 
?>
</body>
</html>