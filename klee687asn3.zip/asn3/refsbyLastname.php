<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Assignment3 </title>
</head>
<body>

<h2> List the officials in order by last name </h2>

<?php
include 'db.php'; //This php file will make a connection to the database you created.
$query='SELECT * FROM refsOfficial ORDER BY LastName'; // this query will list the officials in order by last name
$result = pg_query($query);
  if (!$result) {
     die ("Database query failed!");
  }

while ($row = pg_fetch_Array($result)) {
     echo("<li>");
     echo "<b>Official ID: </b>".$row[0]."<li>"; 
     echo "<b>First Name: </b>".$row[1]."<li>";
     echo "<b>Last Name:</b>".$row[2]."<li>";
     echo "<b>City: </b>".$row[3]."<li>";  
  }

  pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
   pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</body>
</html>
 