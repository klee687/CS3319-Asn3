<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> KJ's assignment3 </title>
</head>
<body>


<h1>Update Your Game</h1>                                                           
<?php
   include 'db.php'; //This php file will make a connection to the database you created.
   $GameID = $_POST["gameid"];
   $_SESSION["gameid"] = $GameID;
   $query = 'SELECT GameID,GameCity FROM Game WHERE GameID = \''.$GameID.'\''; 
   $result = pg_query($query);
   if(pg_num_rows($result)>0){    
        $row = pg_fetch_array($result);
        echo "The Game ID ".$row[0]." is from ".$row[1].".<br><br>";
  }else{
        die("The game ID you inserted was not found." . pg_last_error($connection));
       }
  pg_free_result($result); //frees the memory and data associated with the specified PostgreSQL query result resource. 
  pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>



<!--this page will be on the second page -->
<p> 
<form action="updatecity.php" method="post">
New Game City: <input type = "text" name = "gamecity"></input><br><br> <!--Ask what location a user wants to set for the game -->
 <input type = "submit" value = "Update a city">  <!--submit button -->
</input></form>
</p>

</body>
</html>