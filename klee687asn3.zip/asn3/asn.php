<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> Kyungjoo Lee CS3319 asn3 </title>
</head>
<body>

<?php 
 include 'db.php'; //This php file will make a connection to the database you created. 
?>

<h1>CS3319 Assignment3</h1>

<h2>Team Name or Team City</h2>
<h4>List all Teams in alphabetical order by team name:</h4>
<form action = "getTeamsname.php" method="post"> <!--getTeamsname.php displays team inf ordered by team name, and the data is retrieved from Lteamname.php -->

<?php
 include ("Lteamname.php");
?>
<input type="submit" value="Team Names"> <!--create a button that is linked to getTeamsname.php-->
</form>

<h4>List all Teams in alphabetical order by team city:</h4>
<form action = "getTeamscity.php" method="post"> <!--getTeamCity.php displays team inf ordered by team city, and the data is retrieved from Lteamcity.php -->
<?php
 include 'Lteamcity.php';
?>
<input type="submit" value="Team Cities"> <!--create a button that is linked to getTeamscity.php-->
</form>

<br><br>
<h2> ADD A NEW TEAM:</h2>
<form action="addnewteam.php" method="post"> <!--Addnewteam.php lets a user to create a new team -->
New Team's ID: <input type="text" name="teamid"><br><br> <!--create a textbox that is linked to new team ID-->
New Team's City: <input type="text" name="teamcity"><br><br> <!--create a textbox that is linked to new team city-->
New Team's Name: <input type="text" name="teamname"><br><br> <!--create a textbox that is linked to new team name-->
<?php
include 'Lteamname.php';
?>
<input type = "submit" value = "Add a new team"> <!--create a button to submit-->
</form>

<br><br>
<h2> DELETE A NEW TEAM:</h2>
<form action="deleteteam.php" method="post"> <!--deleteteam.php lets a user to delete a team -->
Team ID: <input type="text" name="teamid"><br><br> <!--create a textbox that is linked to team ID -->
<?php
include 'Lteamname.php';
?>
<input type = "submit" value = "Delete a team"><br> <!--create a submit button-->
</form>

<br><br>
<h2> UPDATE A GAME:</h2>
<form action="updategame.php" method="post"> <!--updateteam.php lets a user to update a team location -->
Game ID: <input type="text" name="gameid"><br><br> <!--create a textbox that is linked to Game ID -->
<?php
include 'game.php';
?>
<input type = "submit" value = "update a game"> <!--create a submit button-->
</form>


<br><br>
<h2> Let the user to pick a game id and output the teams: </h2>
<form action = "highlight.php" method = "post"> <!--highlight.php displays a game ID and teams' output. -->
Game ID: <input type="text" name="gameid"><br><br><!--create a textbox that is linked to Game ID -->
<?php
include ("game.php");
?>
<input type="submit" value="List a game id"> <!--create a submit button-->
</form>	


<br><br>	
<h2> List the officials by last name: </h2>
<form action = "refsbyLastname.php" method = "post"> <!--refsbyLastname.php displays officiators by their last names. -->
<?php
 include ("refsofficial.php");
?>
<input type="submit" value="List officials"> <!--create a submit button-->
</form>	


<br><br>
<h2> Did the Maple Leafs have a curse on them because of the officials? </h2>
Click to Display<br><br>
<form action = "maple.php" method = "post">
<input type="submit" value="The scores for all the games that the Leafs played in and their opponents name and city"><br><br></form>  <!--create a submit button-->

<form action = "maple1.php" method = "post">
<input type="submit" value="The name of the official who has officiated the most Leafs games"><br><br></form>  <!--create a submit button-->

<form action = "maple2.php" method = "post">
<input type="submit" value="The name of the official who had officiated the most Leaf losses"><br><br></form>  <!--create a submit button-->

<form action = "maple3.php" method = "post">
<input type="submit" value="The name of the official who has officiated the most Leaf wins"><br><br></form>  <!--create a submit button-->

<?php
 pg_close($connection);  //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource. 
?>

</body>
</html>