<!––KYUNGJOO LEE || STUDENT #250 855 791 || CS3319 ASSIGNMENT3 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> KJ's assignment3 </title>
</head>
<body>

<h2> Delete your team </h2>
<ol>
  
<?php
   include 'db.php'; //This php file will make a connection to the database you created.
   $TeamID= $_POST["teamid"]; //retrieve a Team ID that user inserted from a main page.
   $query1= "SELECT TeamID AS TeamID FROM Team WHERE teamid = '$TeamID'";
   $result = pg_query($query1); //pg_query() executes the query on the specified database connection.
   if (!$result)  { //if the query was not executed
          die("database query failed.".pg_last_error($connection)); 
   }

   while ($row=pg_fetch_array($result)){ //returns an array that corresponds to $result. 
   $query = "DELETE FROM Team WHERE teamid = '$TeamID'";
     if (!pg_query($query)) {
        echo "failed2";
        die("Error: delete failed-->".pg_last_error($connection));
      }
     else{
        echo "Your team was deleted!"; //The query was successful.
      }
  }
   pg_close($connection); //pg_close() closes the non-persistent connection to a PostgreSQL database associated with the given connection resource.
?>
</ol>
</body>
</html>
